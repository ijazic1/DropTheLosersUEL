# Density: P(Z_tau = z)
d_ztau <- function(z, pi, n1, n2, bytrts = FALSE){

  ntrts <- length(pi)

  # Generate relevant probabilities under each arm
  prob.lst <- vector("list", length = ntrts)
  g <- c()
  start1 <- "sum(sapply(max(0, z - n2):min(z, n1), function(i){"
  start2n <- "sum(sapply(max(1, z - n2):min(z, n1), function(i){"
  end <- "}))"


  for (i in 1:ntrts){
    for (j in 1:(ntrts + 1)){
      if (i == j){
        prob.lst[[i]][j] <- paste("dbinom(i, n1, pi[", j, "])", sep = "")
      } else{
        if (j < i) {
          prob.lst[[i]][j] <- paste("pbinom(i - 1, n1, pi[", j, "])", sep = "")
        } else if (j > i & j != (ntrts + 1)){
          prob.lst[[i]][j] <- paste("pbinom(i, n1, pi[", j, "])", sep = "")
        } else if (j == (ntrts + 1)){
          prob.lst[[i]][j] <- paste("dbinom(z - i, n2, pi[", i, "])", sep = "")
        }
      }
    }
    if (i == 1){
      prob.lst[i] <- paste(start1, paste(prob.lst[[i]], collapse = " * "), end, sep = "")
    }else {
      prob.lst[i] <- paste(start2n, paste(prob.lst[[i]], collapse = " * "), end, sep = "")
    }
  }

  if (bytrts == FALSE){
    out <- sum(sapply(1:ntrts, function(i){g[i] <- eval(parse(text = prob.lst[i]))}))
  }else {
    out <- sapply(1:ntrts, function(i){g[i] <- eval(parse(text = prob.lst[i]))})
  }

  return(out)
}

# Example code
# d_ztau(z = 5, ntrts = 3, pi = c(0.1, 0.1, 0.1), n1 = 11, n2 = 12)

#################################################################################################################

# CDF
# P(Z <= z) or P(Z > z) if lower.tail = TRUE
p_ztau <- function(z, pi, n1, n2, lower.tail = TRUE, bytrts = FALSE){

  if(bytrts == FALSE){
    if (lower.tail == TRUE){
      return(sum(sapply(0:z, function(i){d_ztau(z = i, pi = pi, n1 = n1, n2 = n2)})))
    }else{
      return(1 - sum(sapply(0:z, function(i){d_ztau(z = i, pi = pi, n1 = n1, n2 = n2)})))
    }
  }else{
    if (lower.tail == TRUE){
      out.bytrts <- sapply(0:z, function(i){d_ztau(z = i, pi = pi, n1 = n1, n2 = n2, bytrts = TRUE)})
      return(apply(out.bytrts, 1, sum))
    }else{
      out.bytrts <- sapply((z + 1):(n1 + n2), function(i){d_ztau(z = i, pi = pi, n1 = n1, n2 = n2, bytrts = TRUE)})
      return(apply(out.bytrts, 1, sum))
    }
  }
}

# Example code
# p_ztau(z = 6, n1 = 11, n2 = 12, lower.tail = FALSE)
# By trts:
# p_ztau(z = 6, n1 = 11, n2 = 12, lower.tail = FALSE, bytrts = T)


#################################################################################################################

# CDF
p_ztau_cond <- function(z, pi, tau, n1, n2, lower.tail = TRUE){

  if (lower.tail == TRUE){
    return(sum(sapply(0:z, function(i){d_ztau_cond(z = i, pi = pi, tau = tau,
                                                   n1 = n1, n2 = n2)})))
  }else{
    return(1 - sum(sapply(0:z, function(i){d_ztau_cond(z = i, pi = pi, tau = tau,
                                                       n1 = n1, n2 = n2)})))
  }
}

# Example code
# p_ztau_cond(z = 6, pi = c(0.1, 0.4, 0.1), tau = 2, n1 = 11, n2 = 12, lower.tail = FALSE)



################################################################################################################
# Conditional
# Density
d_ztau_cond <- function(z, pi, tau, n1, n2){

  ntrts <- length(pi)

  # Generate relevant probabilities under each arm
  prob.vec <- c()
  prob.denom.vec <- c()
  g <- c()
  start1 <- "sum(sapply(max(0, z - n2):min(z, n1), function(i){"
  start2n <- "sum(sapply(max(1, z - n2):min(z, n1), function(i){"
  start1.denom <- "sum(sapply(0:(n1 + n2), function(j){sum(sapply(max(0, j - n2):min(j, n1), function(i){"
  start2n.denom <- "sum(sapply(1:(n1 + n2), function(j){sum(sapply(max(1, j - n2):min(j, n1), function(i){"
  end <- "}))"
  end.denom <- "}))}))"

  for (j in 1:(ntrts + 1)){
    if (tau == j){
      prob.vec[j] <- paste("dbinom(i, n1, pi[", j, "])", sep = "")
      prob.denom.vec[j] <- prob.vec[j]
    } else{
      if (j < tau) {
        prob.vec[j] <- paste("pbinom(i - 1, n1, pi[", j, "])", sep = "")
        prob.denom.vec[j] <- prob.vec[j]
      } else if (j > tau & j != (ntrts + 1)){
        prob.vec[j] <- paste("pbinom(i, n1, pi[", j, "])", sep = "")
        prob.denom.vec[j] <- prob.vec[j]
      } else if (j == (ntrts + 1)){
        prob.vec[j] <- paste("dbinom(z - i, n2, pi[", tau, "])", sep = "")
        prob.denom.vec[j] <- paste("dbinom(j - i, n2, pi[", tau, "])", sep = "")
      }
    }
  }

  if (tau == 1){
    prob.vec <- paste(start1, paste(prob.vec, collapse = " * "), end, sep = "")
    prob.denom.vec <- paste(start1.denom, paste(prob.denom.vec, collapse = " * "), end.denom, sep = "")
  }else {
    prob.vec <- paste(start2n, paste(prob.vec, collapse = " * "), end, sep = "")
    prob.denom.vec <- paste(start2n.denom, paste(prob.denom.vec, collapse = " * "), end.denom, sep = "")
  }

  out <- eval(parse(text = prob.vec))/eval(parse(text = prob.denom.vec))

  return(out)
}

# Example code
# dens_ztau_cond(z = 7, pi = c(0.1, 0.4, 0.1), tau = 1, n1 = 11, n2 = 12)

#################################################################################################################

# Expectation, Variance
meanvar_ztau_cond <- function(pi, tau, n1, n2){

  z.max <- n1 + n2

  z.candidate <- 0:z.max

  p.z <- sapply(z.candidate, function(i){d_ztau_cond(z  = i,
                                                     pi = pi,
                                                     tau = tau,
                                                     n1 = n1,
                                                     n2 = n2)})
  mean <- sum(z.candidate * p.z)

  var <- sum(z.candidate^2 * p.z) - mean^2

  return(list("Mean" = mean, "Variance" = var))
}

# Example code
# meanvar_ztau_cond(pi = c(0.3, 0.3, 0.4), tau = 3, ntrts = 3, n1 = 11, n2 = 12)

#################################################################################################################

# lower bound
# obs.z: observed z
# pi.est: estimated probability vector ("Plug-in" value for nuisance parameters).
#         E.g. if pi.est = c(0.4, 0.3, 0.2) and tau = 3, then pi.est[1] and pi.est[2] are
#              plugged in and pi.est[3] will be ignored and the lower bound is for pi[3]

lb_ztau <- function(obs.z, pi.est, tau, n1, n2, alpha, precision, norm.approx=FALSE){

  ### lower bound
  curr.prob <- 0
  int.l <- 0
  int.h <- 1
  lb <- 0.5
  counter <- 1

  while(abs(curr.prob - alpha) > precision){

    curr.l <- pi.est
    curr.l[tau] <- lb

    if(norm.approx==FALSE){
      curr.prob <- p_ztau_cond(z  = obs.z - 1,
                               pi = curr.l,
                               tau = tau,
                               n1 = n1,
                               n2 = n2,
                               lower.tail = FALSE)
    }else if(norm.approx==TRUE){
      alt.params <- meanvar_ztau_cond(pi=curr.l, tau=tau, n1=n1, n2=n2)
      curr.prob <- pnorm((obs.z-0.5), mean=alt.params$Mean, sd=sqrt(alt.params$Variance), lower.tail=FALSE)
    }


    if (abs(curr.prob - alpha) > precision){
      if(curr.prob < alpha){
        int.l <- lb
        lb <- (int.l + int.h)/2
      }else if(curr.prob > alpha){
        int.h <- lb
        lb <- (int.l + int.h)/2
      }else if(curr.prob == alpha){
        lb <- lb
      }
    }
    if(lb < precision){
      lb <- 0
      break
    }
    counter <- counter + 1
    if(counter >= 30){
      print("Time out")
      lb <- lb
      break
    }
  }

  return(lb)
}

#################################################################################################################

# upper bound
# pi.est: estimated probability vector ("Plug-in" value for nuisance parameters).
#         E.g. if pi.est = c(0.4, 0.3, 0.2) and tau = 3, then pi.est[1] and pi.est[2] are
#              plugged in and pi.est[3] will be ignored and the upper bound is for pi[3]

ub_ztau <- function(obs.z, pi.est, tau, n1, n2, alpha, precision, norm.approx=FALSE){

  ### upper bound
  curr.prob <- 0
  int.l <- 0
  int.h <- 1
  ub <- 0.5
  counter <- 1

  while(abs(curr.prob - alpha) > precision){

    curr.u <- pi.est
    curr.u[tau] <- ub

    if(norm.approx==FALSE){
      curr.prob <- p_ztau_cond(z  = obs.z,
                               pi = curr.u,
                               tau = tau,
                               n1 = n1,
                               n2 = n2)
    }else if(norm.approx==TRUE){
      alt.params <- meanvar_ztau_cond(pi=curr.u, tau=tau, n1=n1, n2=n2)
      curr.prob <- pnorm((obs.z+0.5), mean=alt.params$Mean, sd=sqrt(alt.params$Variance), lower.tail=TRUE)
    }


    if (abs(curr.prob - alpha) > precision){
      if(curr.prob < alpha){
        int.h <- ub
        ub <- (int.l + int.h)/2
      }else if(curr.prob > alpha){
        int.l <- ub
        ub <- (int.l + int.h)/2
      }else if(curr.prob == alpha){
        ub <- ub
      }
    }
    if((1 - ub) < precision){
      ub <- 1
      break
    }
    if(ub < precision){
      ub <- 0
      break
    }
    counter <- counter + 1
    if(counter >= 30){
      print("Time out")
      ub <- ub
      break
    }
  }
  return(ub)
}


###########################################################################################

# Derive the probability of having ties at the first stage
# Function psum.ties is embeded in p_ties
psum_ties <- function(p, p.rest, n1, ntrts){

  prob.vec <- c()
  prob.rest <- c()

  num.dbinom <- length(p)

  for (k in 1:num.dbinom){
    prob.vec[k] <- paste("dbinom(k, n1, p[", k, "])", sep = "")
  }

  if (num.dbinom < ntrts){
    for (k in 1:(ntrts - num.dbinom)){
      prob.rest[k] <- paste(paste("pbinom(k - 1, n1, p.rest[", k, "])", sep = ""))
    }
  }else{prob.rest = 1}


  final <- paste(paste(prob.vec, collapse = "*"), "*", paste(prob.rest, collapse = "*"))


  if (num.dbinom < ntrts){
    psum <- sum(sapply(1:n1, function(k){eval(parse(text = final))}))
  }else {
    psum <- sum(sapply(0:n1, function(k){eval(parse(text = final))}))
  }

  return(psum)
}
