#' @import ggplot2
#' @importFrom stats pnorm
#' @importFrom stats qnorm
#' @importFrom utils combn
NULL


#' p-value for UEL test
#'
#' This function provides the p-value for for a one-sided level \eqn{\alpha} UEL test of \eqn{\pi_\tau} vs. the specified \eqn{\pi_0},
#' based on the distribution of \eqn{Z_\tau}, the total number of responses (across Stages 1 and 2) for the treatment selected at the
#' end of Stage 1. This function also supports a normal approximation to the UEL test.
#'
#'
#' @return \code{pval_ztau} returns a single element with the p-value for a one-sided test of \eqn{\pi_\tau} vs. the specified \eqn{\pi_0}.
#'
#'
#' @examples
#'pval_ztau(z = 6, ntrts=3, pi0=0.1, n1 = 12, n2 = 12)
#'pval_ztau(z = 6, ntrts=3, pi0=0.1, n1 = 40, n2 = 40, norm.approx=TRUE)
#'pval_ztau(z = 6, ntrts=3, pi0=0.1, n1 = 40, n2 = 40, norm.approx=FALSE)
#'
#' @param z Total (observed) number of responses (across Stages 1 and 2) for selected treatment \eqn{\tau}
#' @param pi0 (Known) control or comparison response rate
#' @param ntrts Number of treatments investigated in Stage 1
#' @param n1 Number of subjects per treatment in Stage 1
#' @param n2 Number of subjects receiving the selected treatment \eqn{\tau} in Stage 2
#' @param norm.approx Indicator of whether the normal approximation (with continuity correction) should be used instead of the UEL method, defaults to \code{FALSE}
#'
#' @rdname pval_ztau
#' @export
#######################################################################################################


pval_ztau <- function(z, pi0, ntrts, n1, n2, norm.approx=FALSE){

  if(z<0|z>(n1+n2)){
    stop("Error: z must be between 0 and n1+n2, inclusive")
  }
  if(pi0<0|pi0>1){
    stop("Error: pi0 must be between 0 and 1, inclusive")
  }
  if(norm.approx==TRUE & (n1+n2)*pi0<5){
    warning("Warning: (n1+n2)*pi0<5. The normal approximation may not be valid.")
  }
  if(norm.approx==TRUE & (n1+n2)*(1-pi0)<5){
    warning("Warning: (n1+n2)*(1-pi0)<5. The normal approximation may not be valid.")
  }
  if(is.na(ntrts)){
    stop("Error: ntrts must be specified")
  }

  if(norm.approx==FALSE){
    pval <- p_ztau(z = z-1, pi=rep(pi0, ntrts), n1 = n1, n2 = n2, lower.tail = FALSE)
  }else if(norm.approx==TRUE){
    null.params <- meanvar_ztau(pi=rep(pi0, ntrts), n1=n1, n2=n2)
    pval <- pnorm((z-0.5), mean=null.params$Mean, sd=sqrt(null.params$Variance), lower.tail=FALSE)
  }

  return(pval)

}


#################################################################################################################


#' Critical value for UEL test
#'
#' This function provides the critical value for a one-sided level \eqn{\alpha} UEL test of \eqn{\pi_\tau} vs. the specified \eqn{\pi_0},
#' based on the distribution of \eqn{Z_\tau}, the total number of responses (across Stages 1 and 2) for the treatment selected at the
#' end of Stage 1. Such a test would be rejected if the observed \eqn{Z_\tau} is greater than or equal to this critical value.
#' This function also supports a normal approximation to the UEL test.
#'
#'
#' @return \code{crit_ztau} returns a single element with the critical value for a one-sided level-alpha test of \eqn{\pi_\tau}
#' vs. the specified \eqn{\pi_0}.
#'
#'
#' @examples
#'crit_ztau(pi0=0.1, ntrts=3, n1 = 12, n2 = 12)
#'crit_ztau(pi0=0.1, ntrts=3, n1 = 40, n2 = 40, norm.approx=TRUE)
#'crit_ztau(pi0=0.1, ntrts=3, n1 = 40, n2 = 40, norm.approx=FALSE)
#'
#' @param pi0 (Known) control or comparison response rate
#' @param ntrts Number of treatments investigated in Stage 1
#' @param n1 Number of subjects per treatment in Stage 1
#' @param n2 Number of subjects receiving the selected treatment \eqn{\tau} in Stage 2
#' @param alpha Significance level; defaults to 0.025
#' @param norm.approx Indicator of whether the normal approximation (with continuity correction) should be used instead of the UEL method; defaults to \code{FALSE}
#'
#' @rdname crit_ztau
#' @export
#######################################################################################################


crit_ztau <- function(pi0, ntrts, n1, n2, alpha = 0.025, norm.approx=FALSE){

  if(pi0<0|pi0>1){
    stop("Error: pi0 must be between 0 and 1, inclusive")
  }
  if(alpha<0|alpha>1){
    stop("Error: alpha cannot be less than 0 or greater than 1")
  }
  if(norm.approx==TRUE & (n1+n2)*pi0<5){
    warning("Warning: (n1+n2)*pi0<5. The normal approximation may not be valid.")
  }
  if(norm.approx==TRUE & (n1+n2)*(1-pi0)<5){
    warning("Warning: (n1+n2)*(1-pi0)<5. The normal approximation may not be valid.")
  }
  if(is.na(ntrts)){
    stop("Error: ntrts must be specified")
  }


  pi.null <- rep(pi0, ntrts)
  z.max <- n1 + n2
  z.start <- 0; z.end <- z.max
  num.candidates <- z.end - z.start

  if(norm.approx==FALSE){

    while(num.candidates > 20){
      z.curr <- floor((z.start + z.end)/2)
      p.curr <- p_ztau(z = z.curr, pi = pi.null, n1 = n1, n2 = n2, lower.tail = FALSE)
      if (p.curr > alpha){
        z.start <- z.curr; z.end <- z.end
      }else{
        z.start <- z.start; z.end <- z.curr
      }
      z.curr <- floor((z.start + z.end)/2)
      num.candidates <- z.end - z.start
    }

    p.crit <- sapply(z.start:z.end, function(i){p_ztau(z = i, pi = pi.null, n1 = n1, n2 = n2, lower.tail = FALSE)}) - alpha

    crit <- z.start + min(which(p.crit <= 0))

  }else if(norm.approx==TRUE){
    null.params <- meanvar_ztau(pi=pi.null, n1=n1, n2=n2)
    crit <- qnorm(p=alpha, mean=null.params$Mean, sd=sqrt(null.params$Variance), lower.tail=F)
  }

  return(crit)


}


#################################################################################################################

#' Power and type 1 error for UEL test
#'
#'
#' This function provides the power/type 1 error for a one-sided level alpha UEL test of \eqn{\pi_\tau} vs. the specified \eqn{\pi_0},
#' based on the distribution of \eqn{Z_\tau}, the total number of responses (across Stages 1 and 2) for the treatment selected at the
#' end of Stage 1. This function also supports a normal approximation to the UEL test.
#'
#'
#' @return If \code{pi.alt} is not provided, then \code{pwr_ztau} returns a list containing the critical value and the type 1 error. If
#' \code{pi.alt} is provided, then \code{pwr_ztau} returns a list containing the critical value and power. For \code{norm.approx=FALSE},
#' type 1 error/power by treatment is also provided as a third element in the list.
#'
#'
#' @examples
#'pwr_ztau(pi0=0.1, ntrts=3, pi.alt = c(0.3, 0.1, 0.1), n1 = 12, n2 = 12)
#'pwr_ztau(pi0=0.1, ntrts=3, n1=12, n2=12)
#'
#' @param pi0 (Known) control or comparison response rate
#' @param ntrts Number of treatments investigated in Stage 1
#' @param pi.alt Vector of response rates under the alternative hypothesis with length \code{ntrts}
#' @param n1 Number of subjects per treatment in Stage 1
#' @param n2 Number of subjects receiving the selected treatment \eqn{\tau} in Stage 2
#' @param alpha Significance level; defaults to 0.025
#' @param norm.approx Indicator of whether the normal approximation (with continuity correction) should be used instead of the UEL method; defaults to \code{FALSE}
#'
#' @rdname pwr_ztau
#' @export
#######################################################################################################


pwr_ztau <- function(pi0, ntrts, pi.alt  = NA, n1, n2, alpha = 0.025, norm.approx=FALSE){

  if(all(!is.na(pi.alt))){
    if(ntrts!=length(pi.alt)){
      stop("Error: pi.alt must have length equal to ntrts")
    }
    if(any(pi.alt<0)|any(pi.alt>1)){
      stop("Error: all elements of pi.alt must be between 0 and 1, inclusive")
    }
    if(length(pi.alt)!=ntrts){
      stop("Error: pi.alt must be a vector of length ntrts")
    }
  }

  if(pi0<0|pi0>1){
    stop("Error: all elements of pi.null must be between 0 and 1, inclusive")
  }
  if(alpha<0|alpha>1){
    stop("Error: alpha cannot be less than 0 or greater than 1")
  }
  if(norm.approx==TRUE & (n1+n2)*pi0<5){
    warning("Warning: (n1+n2)*pi0<5. The normal approximation may not be valid.")
  }
  if(norm.approx==TRUE & (n1+n2)*(1-pi0)<5){
    warning("Warning: (n1+n2)*(1-pi0)<5. The normal approximation may not be valid.")
  }

  pi.null <- rep(pi0, ntrts)

  crit <- crit_ztau(pi0=pi0, ntrts=ntrts,
                          n1 = n1, n2 = n2,
                          alpha = alpha, norm.approx=norm.approx)

  if (any(is.na(pi.alt))){

    if(norm.approx==TRUE){
      null.params <- meanvar_ztau(pi=pi.null, n1=n1, n2=n2)
      dens.vec <- sapply(ceiling(crit+0.5):(n1+n2), function(jj) d_ztau(z=jj, pi= pi.null, n1=n1, n2=n2))
      typ1err <- sum(dens.vec)
      return(list("Critical Value" = crit,
                  "Type 1 Error"   = typ1err))

    }else if(norm.approx==FALSE){
      typ1err <- p_ztau(z = crit - 1, pi = pi.null,
                        n1 = n1, n2 = n2, lower.tail = FALSE)
      typ1err_bytrts <- p_ztau(z = crit - 1, pi = pi.null,
                               n1 = n1, n2 = n2, lower.tail = FALSE, bytrts = T)
      return(list("Critical Value" = crit,
                  "Type 1 Error"   = typ1err,
                  "Type 1 Error by Treatment" = typ1err_bytrts))
    }

  }else{

    if(norm.approx==TRUE){
      dens.vec <- sapply(ceiling(crit+0.5):(n1+n2), function(jj) d_ztau(z=jj, pi= pi.alt, n1=n1, n2=n2))
      pwr <- sum(dens.vec)
      return(list("Critical Value" = crit,
                  "Power"          = pwr))

    }else if(norm.approx==FALSE){
      pwr <- p_ztau(z = crit - 1, pi = pi.alt,
                    n1 = n1, n2 = n2, lower.tail = FALSE)

      pwr_bytrts <- p_ztau(z = crit - 1, pi = pi.alt,
                           n1 = n1, n2 = n2, lower.tail = FALSE, bytrts = T)
      return(list("Critical Value" = crit,
                  "Power"          = pwr,
                  "Power by Treatment" = pwr_bytrts))
    }


  }
}


#################################################################################################################
#' Mean and variance of \eqn{Z_\tau}
#'
#'
#' This function provides the mean and variance of \eqn{Z_\tau}, the total number of responses (across Stages 1 and 2) for the
#' treatment selected at the end of Stage 1, for a specified vector of true response rates.
#'
#'
#' @return \code{meanvar_ztau} returns a list where the first element is the mean and the second element is the variance.
#'
#'
#' @examples
#'meanvar_ztau(pi = c(0.3, 0.3, 0.4), n1 = 11, n2 = 12)
#'
#' @param pi Vector of response rates for each treatment
#' @param n1 Number of subjects per treatment in Stage 1
#' @param n2 Number of subjects receiving the selected treatment \eqn{\tau} in Stage 2
#'
#' @rdname meanvar_ztau
#' @export
#######################################################################################################


# Expectation, Variance of ztau
meanvar_ztau <- function(pi, n1, n2){

  if(any(pi<0)|any(pi>1)){
    stop("Error: all elements of pi must be between 0 and 1, inclusive")
  }

  z.max <- n1 + n2

  z.candidate <- 0:z.max

  p.z <- sapply(z.candidate, function(i){d_ztau(z  = i,
                                                      pi = pi,
                                                      n1 = n1,
                                                      n2 = n2)})

  mean <- sum(z.candidate * p.z)

  var <- sum(z.candidate^2 * p.z) - mean^2

  return(list("Mean" = mean, "Variance" = var))
}

# Example code
# meanvar_ztau(pi = c(0.3, 0.3, 0.4), n1 = 11, n2 = 12)

#################################################################################################################


#################################################################################################################
#' Point estimator (UMVUE) for response rate for selected arm
#'
#' This function provides a point estimator of \eqn{\pi_\tau}, the response rate for the treatment selected at the end of Stage 1.
#' This is an implementation of the UMVUE originally proposed in Tappin (1992). This estimator will only be the UMVUE if the
#' standard rules for selecting \eqn{\tau} are followed (i.e., the arm with the highest Stage 1 response is selected;
#' in case of ties, the treatment with the smallest index is selected).
#'
#'
#' @return \code{est_pitau} returns a single element: the point estimate of the response rate \eqn{\pi_\tau}.
#'
#'
#' @examples
#' est_pitau(stage1.resp.vec=c(5,3,3), stage2.resp=5, tau=1, n1=12, n2=12)
#'
#' @param stage1.resp.vec Vector of the observed number of responses for all treatment arms in Stage 1
#' @param stage2.resp Observed number of responses for the selected treatment arm in Stage 2
#' @param tau Index for the selected treatment arm
#' @param n1 Number of subjects per treatment in Stage 1
#' @param n2 Number of subjects receiving the selected treatment \eqn{\tau} in Stage 2
#'
#' @rdname est_pitau
#' @export
#######################################################################################################

est_pitau <- function(stage1.resp.vec, stage2.resp, tau, n1, n2){

  if(any(stage1.resp.vec<0)|any(stage1.resp.vec>n1)){
    stop("Error: number of Stage 1 responses must be between 0 and n1, inclusive")
  }
  if(stage2.resp<0|stage2.resp>n2){
    stop("Error: number of Stage 2 responses must be between 0 and n2, inclusive")
  }
  if(tau<1|tau>length(stage1.resp.vec)){
    stop("Error: the specified value of tau is not an eligible treatment")
  }

  x1 <- stage1.resp.vec[tau]
  index1 <- tau

  max.arm <- which(stage1.resp.vec==max(stage1.resp.vec))
  if(length(max.arm)==1){
    select.arm <- max.arm
    index2 <- min(which(stage1.resp.vec==sort(stage1.resp.vec[-tau],TRUE)))
    x2 <- stage1.resp.vec[index2]
  }else if(length(max.arm)>1){
    # if two or more arms share highest response rate, select the highest dose (i.e., LOWER index)
    select.arm <- min(max.arm)
    index2 <- min(max.arm[-tau])
    x2 <- stage1.resp.vec[select.arm]
  }
  if(select.arm!=tau){
    warning("Warning: the specified tau is not the most preferred treatment based on the Stage 1 responses. This estimator is no longer the UMVUE")
  }

  z1 <- x1+stage2.resp
  z2 <- x2
  if(z1-z2>n2){
    est <- z1/(n1+n2)
  }else if(index1<index2){
    num <- sum(sapply(0:(z1-z2), function(yy) yy*choose(n2,yy)*choose(n1, z1-yy)))
    denom <-sum(sapply(0:(z1-z2), function(yy) choose(n2,yy)*choose(n1, z1-yy)))
    est <- num/(n2*denom)
  }else if(index1>index2){
    num <- sum(sapply(0:(z1-z2-1), function(yy) yy*choose(n2,yy)*choose(n1, z1-yy)))
    denom <-sum(sapply(0:(z1-z2-1), function(yy) choose(n2,yy)*choose(n1, z1-yy)))
    est <- num/(n2*denom)
  }
  return(est)
}



#################################################################################################################
#' Confidence interval based on UEL test
#'
#' This function provides a confidence interval for \eqn{\pi_\tau}, the response rate for the treatment selected at the end of Stage 1,
#' based on the UEL test. The observed response rates in the non-selected arms are used as plug-in estimates of the response rates in the
#' non-selected arms. This function also supports confidence intervals for a normal approximation to the UEL test.
#'
#'
#' @return \code{ci_ztau} returns a vector with two elements: the lower and upper bound of the confidence interval.
#'
#'
#' @examples
#' ci_ztau(resp.vec=c(12,3,3), tau=1, n1=12, n2=12)
#' ci_ztau(resp.vec=c(24,10,10), tau=1, n1=40, n2=40, norm.approx=TRUE)
#'
#' @param resp.vec Vector of the observed number of responses for all treatment arms. Element \eqn{\tau} of this vector contains responses from
#' both stages
#' @param tau Index for the selected treatment arm
#' @param n1 Number of subjects per treatment in Stage 1
#' @param n2 Number of subjects receiving the selected treatment \eqn{\tau} in Stage 2
#' @param two.sided Indicator of whether a two-sided confidence interval should be constructed; defaults to \code{TRUE}. If \code{FALSE},
#' the upper bound for the confidence interval will be 1
#' @param alpha Specified such that a (1-\eqn{\alpha}) confidence interval is constructed; defaults to 0.05
#' @param precision Search for confidence bound stops when |Rejection prb - \code{alpha}/2|<\code{precision} if \code{two.sided=TRUE}
#' (replace \code{alpha}/2 with \code{alpha} if \code{two.sided=FALSE}); defaults to \code{1e-4}
#' @param norm.approx Indicator of whether the normal approximation (with continuity correction) should be used instead of the UEL method; defaults to \code{FALSE}
#'
#' @rdname ci_ztau
#' @export
#######################################################################################################


ci_ztau <- function(resp.vec, tau, n1, n2, two.sided=TRUE, alpha=0.05, precision=1e-4, norm.approx=FALSE){

  z <- resp.vec[tau]
  pi.est <- resp.vec/n1
  pi.est[tau] <- z/(n1+n2)

  if(z<0|z>(n1+n2)){
    stop("Error: number of responses for selected treatment must be between 0 and n1+n2, inclusive")
  }
  if(any(resp.vec[-tau]<0)|any(resp.vec[-tau]>n1)){
    stop("Error: number of responses for non-selected arms must be between 0 and n1, inclusive")
  }
  if(tau<1|tau>length(pi.est)){
    stop("Error: the specified value of tau is not an eligible treatment")
  }
  if(alpha<0|alpha>1){
    stop("Error: alpha cannot be less than 0 or greater than 1")
  }

  ci.lb <- ifelse(two.sided==TRUE, lb_ztau(obs.z = z, pi.est = pi.est, tau=tau, n1 = n1,
                                       n2 = n2, alpha = alpha/2, precision = precision,
                                       norm.approx=norm.approx),
                               lb_ztau(obs.z = z, pi.est = pi.est, tau=tau, n1 = n1,
                                       n2 = n2, alpha = alpha, precision = precision,
                                       norm.approx=norm.approx))

  ci.ub <- ifelse(two.sided==TRUE, ub_ztau(obs.z = z, pi.est = pi.est, tau=tau, n1 = n1,
                                       n2 = n2, alpha = alpha/2, precision = precision,
                                       norm.approx=norm.approx), 1)

  z.ci <- c(ci.lb, ci.ub)

  return(z.ci)
}

#################################################################################################################
#' Probability of selecting a particular treatment at the end of Stage 1
#'
#'
#' This function provides the probability that a given treatment is selected at the end of Stage 1
#' to proceed to Stage 2, for a specified vector of true response rates. A tie-breaking rule applies such that ties
#' are broken in favor of the treatment with a lower index (e.g., 1 over 2). In other words, this function computes
#' the probability that a given treatment has the highest observed number of responses in Stage 1, either outright
#' or if it is favored in a tie.
#'
#'
#' @return \code{p_select_trt} returns the numeric probability that treatment \code{tau} is selected.
#'
#'
#' @examples
#'p_select_trt(tau = 1, pi = c(0.3, 0.2, 0.2), n1 = 12)
#'
#' @param tau Index for the treatment arm of interest
#' @param pi Vector of response rates for each treatment
#' @param n1 Number of subjects per treatment in Stage 1
#'
#' @rdname p_select_trt
#' @export
#######################################################################################################

p_select_trt <- function(tau, pi, n1){

  ntrts <- length(pi)

  if(any(pi<0)|any(pi>1)){
    stop("Error: all elements of pi must be between 0 and 1, inclusive")
  }
  if(tau<1|tau>ntrts){
    stop("Error: the specified value of tau is not an eligible treatment")
  }

  # Generate relevant probabilities under each arm
  prob.denom.vec <- c()
  g <- c()

  start1.denom <- "sum(sapply(0:(n1), function(j){sum(sapply(max(0, j):min(j, n1), function(i){"
  start2n.denom <- "sum(sapply(1:(n1), function(j){sum(sapply(max(1, j):min(j, n1), function(i){"
  end.denom <- "}))}))"

  for (j in 1:ntrts){
    if (tau == j){
      prob.denom.vec[j] <- paste("dbinom(i, n1, pi[", j, "])", sep = "")
    } else{
      if (j < tau) {
        prob.denom.vec[j] <- paste("pbinom(i - 1, n1, pi[", j, "])", sep = "")
      } else if (j > tau & j != (ntrts + 1)){
        prob.denom.vec[j] <- paste("pbinom(i, n1, pi[", j, "])", sep = "")
      }
    }
  }

  if (tau == 1){
    prob.denom.vec <- paste(start1.denom, paste(prob.denom.vec, collapse = " * "), end.denom, sep = "")
  }else {
    prob.denom.vec <- paste(start2n.denom, paste(prob.denom.vec, collapse = " * "), end.denom, sep = "")
  }

  out <- eval(parse(text = prob.denom.vec))

  return(out)

}


#################################################################################################################
#' Plot comparing overall study power and selection of a particular treatment at the end of Stage 1, for a fixed total sample size
#'
#'
#' This function produces a plot that can help decide how a certain total sample size should be allocated between Stage 1 and
#' Stage 2, for a specified vector of true response rates. For various combinations of Stage 1 and Stage 2 sample sizes
#' (under the constraint of the total sample size), the overall study power and the probability of the specified treatment
#' being selected at the end of Stage 1 are plotted as separate curves.
#'
#' @return \code{plot_power_pselecttrt} returns a plot with two curves: the solid line represents the overall study power, and
#' the dotted line represents the probability that treatment \code{tau} is selected.
#'
#'
#' @examples
#'plot_power_pselecttrt(pi0 = 0.1, pi = c(0.2, 0.2, 0.3), tau=1, totalN=45)
#'
#' @param pi0 (Known) control or comparison response rate
#' @param pi Vector of response rates for each treatment
#' @param tau Index for the treatment arm of interest
#' @param totalN Total number of subjects in the study. In the plot, n1 and n2 are constrained to equal \code{totalN},
#' which is n1*ntrts+n2.
#' @param n1start Minimum number of subjects per treatment in Stage 1; defaults to 5
#'
#' @rdname plot_power_pselecttrt
#' @export
#######################################################################################################

plot_power_pselecttrt <- function(pi0, pi, tau, totalN, n1start=5){

  if(any(pi<0)|any(pi>1)){
    stop("Error: all elements of pi must be between 0 and 1, inclusive")
  }
  if(pi0<0|pi0>1){
    stop("Error: pi0 must be between 0 and 1, inclusive")
  }
  if(totalN<=(n1start*length(pi))){
    stop("The current values of n1start and totalN do not allow any subjects in Stage 2")
  }
  if(tau<1|tau>length(pi)){
    stop("Error: the specified value of tau is not an eligible treatment")
  }

  ntrts <- length(pi)
  pi.null <- rep(pi0, ntrts)

  n1.max <- ceiling(totalN / ntrts)

  n1.candidate <- n1start:n1.max
  n2.candidate <- totalN - ntrts * n1.candidate

  n1.candidate <- n1.candidate[n2.candidate >= 0]
  n2.candidate <- n2.candidate[n2.candidate >= 0]

  n1.n2.candidate <- cbind(n1.candidate, n2.candidate)

  out.pwr <- sapply(1:length(n1.candidate), function(i){pwr_ztau(pi0=pi0,
                                                                pi.alt = pi,
                                                                ntrts = ntrts,
                                                                n1 = n1.n2.candidate[i,1],
                                                                n2 = n1.n2.candidate[i,2])[[2]]})

  out.p <- sapply(1:length(n1.candidate), function(i){p_select_trt(tau  = tau,
                                                                    pi = pi,
                                                                    n1 = n1.n2.candidate[i,1])})

  out <- as.data.frame(cbind(n1.n2.candidate,
                               matrix(out.pwr, ncol = 1),
                               matrix(out.p,   ncol = 1)))

  colnames(out) <- c("n1", "n2", "pwr", "p.trt")

  plot.all <- ggplot(data = out) +
      geom_line(aes(x = out[,1], y = out[,3], linetype = "Power"), colour = "black", size = 0.8) +
      geom_line(aes(x = out[,1], y = out[,4], linetype = "Ptau"), colour = "black", size = 0.8) +

      scale_linetype_manual(name = NULL,
                            values = c("Power" = "solid",
                                      "Ptau"  = "dotted"),
                            labels = c("Overall study power", paste("P(Trt ", tau, " selected for Stage 2)",sep="")),
                            breaks = c("Power", "Ptau")) +

      scale_x_continuous(sec.axis = sec_axis(~ totalN - ntrts * ., name = "n2", breaks = totalN - ntrts * seq(n1start, max(n1.candidate), 1)),
                         limits=c(n1start, max(n1.candidate)), breaks = seq(n1start, max(n1.candidate), 1)) +
      xlab("n1") +
      ylab("Probability") +
      scale_y_continuous(limits=c(0, 1), breaks = seq(0, 1, 0.1)) +
      theme_bw() +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
            legend.position="bottom",
            legend.title = element_text(size = 12),
            legend.text  = element_text(size = 12))

  return(plot.all)
}


#################################################################################################################
#' Probability of ties in the highest number of observed responses in Stage 1
#'
#'
#' This function provides the probability of ties in the highest number of observed responses in Stage 1, for a specified
#' vector of true response rates.
#'
#' @return \code{plot_power_pselecttrt} returns a vector of length k, where k is the number of treatments (length \code{pi}),
#' indicating the probabilities of 2-group ties through (k-1)-group ties, as well as the total probability of ties.
#'
#'
#' @examples
#'p_ties(pi = c(0.2, 0.2, 0.3), n1=12)
#'
#' @param pi Vector of response rates for each treatment
#' @param n1 Number of subjects per treatment in Stage 1
#'
#' @rdname p_ties
#' @export
#######################################################################################################


p_ties <- function(pi, n1){

  if(any(pi<0)|any(pi>1)){
    stop("Error: all elements of pi must be between 0 and 1, inclusive")
  }

  ntrts <- length(pi)

  # Generate different combination of ties within fixed number of ties allowed
  ties.combine <- sapply(2:ntrts, function(i){combn(1:ntrts, i)})

  prob.lst <- vector("list", length = length(ties.combine))

  for (i in 1:length(ties.combine)){
    prob.vec <- c()
    for (j in 1:ncol(ties.combine[[i]])){
      notie <- setdiff(1:ntrts, ties.combine[[i]][,j])
      p.rest <- pi[notie]
      p.curr <- pi[ties.combine[[i]][,j]]
      prob.vec[j] <- psum_ties(p = p.curr, p.rest = p.rest, n1 = n1, ntrts = ntrts)
    }
    prob.lst[i] <- sum(prob.vec)
  }

  prob.out <- unlist(prob.lst)
  prob.out[ntrts] = sum(prob.out)

  names(prob.out) <- sapply(2:(ntrts+1), function(i){
    names.prob.out <- c()
    if (i != (ntrts + 1)){
      names.prob.out[i-1] <-  paste(i, "-group ties", sep = "")
    }else{
      names.prob.out[i-1] <-  "Total"
    }
  })
  return(prob.out)
}


